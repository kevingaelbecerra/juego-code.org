var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["1a2b72bf-ece7-4839-a382-f8791d4bd9be","a03d1c1f-e4fa-4146-ac5b-2d8136b38755"],"propsByKey":{"1a2b72bf-ece7-4839-a382-f8791d4bd9be":{"name":"diamond_1","sourceUrl":"assets/api/v1/animation-library/gamelab/RIDiuf2PVUAzqFMR4oK5dkuIKcWIK8TS/category_icons/diamond.png","frameSize":{"x":391,"y":358},"frameCount":1,"looping":true,"frameDelay":2,"version":"RIDiuf2PVUAzqFMR4oK5dkuIKcWIK8TS","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":391,"y":358},"rootRelativePath":"assets/api/v1/animation-library/gamelab/RIDiuf2PVUAzqFMR4oK5dkuIKcWIK8TS/category_icons/diamond.png"},"a03d1c1f-e4fa-4146-ac5b-2d8136b38755":{"name":"blue_dress_wave_1","sourceUrl":"assets/api/v1/animation-library/gamelab/UfFJtfc.juUbbp52INDrU21alR7eS09f/category_people/blue_dress_wave.png","frameSize":{"x":166,"y":378},"frameCount":1,"looping":true,"frameDelay":2,"version":"UfFJtfc.juUbbp52INDrU21alR7eS09f","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":166,"y":378},"rootRelativePath":"assets/api/v1/animation-library/gamelab/UfFJtfc.juUbbp52INDrU21alR7eS09f/category_people/blue_dress_wave.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var rata = createSprite(10, 390, 30, 30);
rata.shapeColor = 'black';
var diamante = createSprite(372, 25, 30, 30);
diamante.shapeColor = 'blue';
diamante.setAnimation("diamond_1");
diamante.scale = 0.1;
var laser1 = createSprite(100, 0, 200, 5);
laser1.shapeColor = 'red';
laser1.velocityY = 2;
var laser2 = createSprite(300, 400, 200, 5);
laser2.shapeColor = 'red';
laser2.velocityY = -2;
createEdgeSprites();
function draw() {
  background("white");
  if (keyDown("RIGHT_ARROW")) {
    rata.velocityX = 2;
    rata.velocityY = 0;
  }
  if (keyDown("LEFT_ARROW")) {
    rata.velocityX = -2;
    rata.velocityY = 0;
  }
  if (keyDown("DOWN_ARROW")) {
    rata.velocityX = 0;
    rata.velocityY = 2;
  }
  if (keyDown("UP_ARROW")) {
    rata.velocityX = 0;
    rata.velocityY = -2;
  }
  if (laser1.isTouching(rata)) {
    strokeWeight(0);
    fill(0);
    textSize(24);
    text("!LADRON ATRAPADO¡", 94, 193);
    laser1.velocityY = 0;
    laser2.velocityY = 0;
    rata.velocityY = 0;
    rata.velocityX = 0;
  }
  if (laser2.isTouching(rata)) {
    strokeWeight(0);
    fill(0);
    textSize(24);
    text("¡LADRON ATRAPADO!", 94, 193);
    laser1.velocityY = 0;
    laser2.velocityY = 0;
    rata.velocityY = 0;
    rata.velocityX = 0;
  }
  if (rata.isTouching(diamante)) {
    strokeWeight(0);
    fill(0);
    textSize(24);
    text("EL LADRON ROBO EL DIAMANTE", 8, 197);
    laser1.velocityY = 0;
    laser2.velocityY = 0;
    rata.velocityY = 0;
    rata.velocityX = 0;
  }
  laser1.bounceOff(topEdge);
  laser1.bounceOff(bottomEdge);
  laser2.bounceOff(topEdge);
  laser2.bounceOff(bottomEdge);
  rata.bounceOff(topEdge);
  rata.bounceOff(bottomEdge);
  rata.bounceOff(leftEdge);
  rata.bounceOff(rightEdge);
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
